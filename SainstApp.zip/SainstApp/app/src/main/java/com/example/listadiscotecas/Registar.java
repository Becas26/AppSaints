package com.example.listadiscotecas;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Registar extends AppCompatActivity {
    TextView btn;


    EditText inputnomeutilizador, inpututilizador, inputpasss, inputbdate, inputphone, inputCODECEORP;
    Button btnRegister;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registar);

        btn = findViewById(R.id.jatemconta);
        inputnomeutilizador = findViewById(R.id.nomeutilizador);
        inpututilizador = findViewById(R.id.utilizador);
        inputpasss = findViewById(R.id.passs);
        inputbdate = findViewById(R.id.bdate);
        inputphone = findViewById(R.id.phone);
        inputCODECEORP = findViewById(R.id.CODERPCEO);

        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                checkCrededentials();
            }
        });

//        startActivity(new Intent(Registar.this,BarList.class));



        checkCrededentials();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Registar.this, MainActivity.class));

            }
        });

        btn =findViewById(R.id.btnRegister);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Registar.this,BdRun.class));

            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void checkCrededentials() {
        try {
            String nome = inputnomeutilizador.getText().toString();
            String user = inpututilizador.getText().toString();
            String password = inputpasss.getText().toString();
            String datanascimento = inputbdate.getText().toString();
            String contacto = inputphone.getText().toString();
            String codigo = inputCODECEORP.getText().toString();

            Log.i("t", datanascimento);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date date = null;
            date = simpleDateFormat.parse(datanascimento);

            Calendar calendar = new GregorianCalendar();
            calendar.setTime(date);

            int year = calendar.get(Calendar.YEAR);
            int yearNow = Year.now().getValue();

            if (inputnomeutilizador.length() < 7) {
                showError(inputnomeutilizador, "O seu nome não está válido");
            } else if (user.length() < 5) {
                showError(inputnomeutilizador, "O seu utilizador não está válido");
            } else if (password.length() < 7) {
                showError(inputpasss, "A sua password não está válido");
            } else if (inputbdate.length() == 0 || yearNow-year < 16) {
                showError(inputbdate, "O seu utilizador não está válido");
            } else if (contacto.length() < 9) {
                showError(inputphone, "O seu contacto não está válido");
            } else {
                Toast.makeText(this, "Registado!", Toast.LENGTH_SHORT).show();
            }
        } catch (ParseException e) {
            showError(inputbdate, "Data O seu utilizador não está válido");
            e.printStackTrace();
        }


    }

    private void showError(EditText input, String s) {
        input.setError(s);
        input.requestFocus();
    }



}
