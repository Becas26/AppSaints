package com.example.listadiscotecas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import kotlin.text.Charsets;

public class BarList extends AppCompatActivity {
    RequestQueue requestQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestQueue = Volley.newRequestQueue(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bar_list);
        BarListView();
    }
    private void BarListView(){
        ListView barList=(ListView) findViewById(R.id.barListView);
        ArrayList<String> barItems = new ArrayList<>();
        ArrayList<String> test = new ArrayList<>();


        Bundle extras = getIntent().getExtras();

        String bdTipo = extras.getString("bdTipo");
        try {
            bdTipo = URLEncoder.encode(bdTipo, Charsets.UTF_8.name());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return;
        }
        String url = "http://10.0.2.2:8080/api/baresdiscoteca/tipo/" + bdTipo;
        StringRequest request = new StringRequest(Request.Method.GET, url, response -> {
            try {
                response = new String(response.getBytes("ISO-8859-1"), "UTF-8");
                JSONArray jsonArray = new JSONArray(response);
                Log.i("resp", response);
                for(int i=0; i<jsonArray.length();i++) {
                    Log.i("a", "v");
                    barItems.add(jsonArray.getJSONObject(i).getString("bdName"));
                }
                ArrayAdapter<String> discoListAdapter= new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, barItems);
                barList.setAdapter(discoListAdapter);
                createListViewClickItemEvent(barList, barItems);
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

        }, error -> Log.e("Error", error.toString())) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json; charset=UTF-8");
                return headers;
            }

            @Override
            public String getBodyContentType() {
                return "application/json; charset=UTF-8";
            }
        };

        requestQueue.add(request);

    }
    private void createListViewClickItemEvent(ListView list, final ArrayList<String> items){
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Log.i("INFO", "O nome da discoteca é: "+items.get(position));
                Intent intent= new Intent(BarList.this, BdDetailView.class);
                intent.putExtra("bdName", items.get(position));
                startActivity(intent);
            }
        });
    }
}