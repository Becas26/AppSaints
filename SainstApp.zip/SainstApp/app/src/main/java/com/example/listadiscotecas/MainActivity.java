package com.example.listadiscotecas;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.util.Log;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    TextView btn;
    EditText inpututilizador,inputpasss;
    Button btnLogin;
    RequestQueue requestQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        requestQueue = Volley.newRequestQueue(this);
        inpututilizador=findViewById(R.id.utilizador);
        inputpasss=findViewById(R.id.passs);
        btnLogin=findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkCrededentials();
            }
        });
        btn =findViewById(R.id.aqui);
        btn.setOnClickListener(view -> startActivity(new Intent(MainActivity.this,Registar.class)));
    } private void checkCrededentials() {
        String username=inpututilizador.getText().toString();
        String password=inputpasss.getText().toString();

        String url = "http://10.0.2.2:8080/api/login";
        StringRequest request = new StringRequest(Request.Method.POST, url, response -> {
            try {
                response = new String(response.getBytes("ISO-8859-1"), "UTF-8");
                if (response.equals("OK")) {
                    // todo passar para a proxima atividade
                    Log.i("Login", "Login successfull");
                } else {
                    // todo o que mostrar quando oops
                    Log.e("Login", "Login unsuccessfull");
                }
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

        }, error -> Log.e("Error", error.toString())) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json; charset=UTF-8");
                return headers;
            }

            @Override
            public String getBodyContentType() {
                return "application/json; charset=UTF-8";
            }

            @Override
            public byte[] getBody() throws AuthFailureError {

                try {
                    JSONObject userObj = new JSONObject();
                    userObj.put("username", username);
                    userObj.put("password", password);

                    return userObj.toString().getBytes(StandardCharsets.UTF_8);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
        btnLogin =findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,BdRun.class));

            }
        });

        requestQueue.add(request);



        if (inpututilizador== null   || username.length()<5)
        {
            showError(inpututilizador, "O seu utilizador não está correto");
        }


        else if (inputpasss== null  || password.length()<5)
        {
            showError(inputpasss, "A sua password não está válido");
        }

        else
        {
            Toast.makeText(this, "LOGIN!", Toast.LENGTH_SHORT).show();
        }

    }

    private void showError(EditText input, String s) {
        input.setError(s);
        input.requestFocus();
    }


   }