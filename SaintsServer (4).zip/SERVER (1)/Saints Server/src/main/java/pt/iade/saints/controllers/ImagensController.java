package pt.iade.saints.controllers;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import pt.iade.saints.models.Imagens;
import pt.iade.saints.models.User;
import pt.iade.saints.models.repositories.ImagensRepository;
import pt.iade.saints.models.repositories.UserRepository;
import pt.iade.saints.models.requests.ImageRequest;
import pt.iade.saints.models.requests.Message;

import java.io.*;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

@RestController
@RequestMapping(path = "/api/imagens")
public class ImagensController {
    @Value("${app.basefolder}/")
    private String baseFolder;

    private Logger logger = LoggerFactory.getLogger(ImagensController.class);
    ResourceLoader resourceLoader;
    @Autowired
    private ImagensRepository imagensRepository;
    @Autowired
    private UserRepository userRepository;

    @GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<Imagens> getImagens() {
        logger.info("Retrieving all imagens");
        return imagensRepository.findAll();
    }

    @PostMapping(path = "/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message addImagens(@RequestBody Imagens imagens, @PathVariable Integer userId) {
        User user = userRepository.findById(userId).orElseThrow();
        if (!user.isUsrIsCeo())
            return new Message("OOPS!");
        logger.info("Saving imagens: {}", imagens.getImgUrl());
        imagensRepository.save(imagens);
        return new Message("Yay!");
    }

    @DeleteMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message deleteImagens(@PathVariable Integer id) {
        logger.info("Deleting imagens by id: {}", id);
        imagensRepository.deleteById(id);
        return new Message("Sucesso");
    }

    @PatchMapping(path = "/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message updateimagens(@RequestBody Imagens imagens, @PathVariable Integer userId) {
        User user = userRepository.findById(userId).orElseThrow();
        if (!user.isUsrIsCeo())
            return new Message("oops");
        logger.info("Update imagens: {}", imagens.getImgUrl());
        imagensRepository.save(imagens);
        return new Message("Alterações efetuadas com sucesso!");
    }

    @PostMapping(path = "/translate", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message translateImage(@RequestBody ImageRequest imageRequest) throws NoSuchAlgorithmException, IOException {
        String b64image = imageRequest.getImage();
        String fileName = hash(b64image);
        File file = new File(baseFolder + fileName);

        logger.info(baseFolder + fileName);
        logger.info("New file declared");
        if (!file.exists()) {
            logger.info("creating file");
            file.createNewFile();
            FileOutputStream f = new FileOutputStream(file);
            f.write(b64image.getBytes());
            f.close();
            logger.info("file created");
        }
        logger.info("End reached");
        return new Message(fileName);
    }

    @GetMapping(path = "/b64/{checksum}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message getImageData(@PathVariable BigInteger checksum) throws IOException {
        String fileName = checksum.toString();
        File file = new File(baseFolder + fileName);
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(file)))) {
            while ((line = bufferedReader.readLine()) != null)
                stringBuilder.append(line);
        }
        return new Message(stringBuilder.toString());
    }

    @GetMapping(path = "/link/{checksum}", produces = MediaType.IMAGE_PNG_VALUE)
    @ResponseBody
    public byte[] getImageUrl(@PathVariable BigInteger checksum) throws IOException {
        String imageData = getImageData(checksum).getMsg();
        logger.info(imageData);
        return Base64.getDecoder().decode(imageData);
    }

    protected String hash(String data) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        BigInteger bigInteger = new BigInteger(1, md.digest(data.getBytes()));
        return bigInteger.toString();
    }

}
