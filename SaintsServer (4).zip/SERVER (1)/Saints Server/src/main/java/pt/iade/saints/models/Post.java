package pt.iade.saints.models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.OffsetDateTime;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "post")
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "post_id", nullable = false)
    private Integer id;

    @Column(name = "post_usr_id")
    private Integer postUsrId;

    @Column(name = "post_bd_id", nullable = false)
    private Integer postBdId;

    @Column(name = "post_txt", nullable = false, length = 200)
    private String postTxt;

    @Column(name = "post_visivel", nullable = false)
    private Boolean postVisivel = false;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "comPostId")
    private Set<Comentario> comentarios = new LinkedHashSet<>();
}
