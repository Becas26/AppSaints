package pt.iade.saints.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "comentario")
public class Comentario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "com_id")
    private int id;
    @Column(name = "com_usr_id")
    private int comUsrId;
    @Column(name = "com_post_id")
    private int comPostId;
    @Column(name = "com_txt")
    private String comTxt;
    @Column(name = "com_visivel")
    private Boolean comVisivel = true;
}