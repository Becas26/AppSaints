package pt.iade.saints.models.repositories;

import org.springframework.data.repository.CrudRepository;
import pt.iade.saints.models.Guest;

public interface GuestRepository extends CrudRepository<Guest, Integer> {
    Guest findGuestById(Integer id);
}
