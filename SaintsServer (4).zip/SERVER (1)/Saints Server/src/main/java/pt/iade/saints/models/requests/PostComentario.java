package pt.iade.saints.models.requests;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
public class PostComentario {
    private int comUsrId;
    private int comPostId;
    private String comTxt;
}