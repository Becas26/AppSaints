package pt.iade.saints.controllers;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import pt.iade.saints.models.User;
import pt.iade.saints.models.repositories.UserRepository;

@AllArgsConstructor
@Getter
@Setter
class LoginUser {
    private String username;
    private String password;
}

@RestController
@RequestMapping(path = "/api/login")
public class LoginController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public String login(@RequestBody LoginUser loginUser) {
        User user = userRepository.findUserByUsrName(loginUser.getUsername());
        if (user == null) {
            return "User is null";
        }

        if (user.getUsrSenha().equals(loginUser.getPassword())) {
            return "OK";
        }

        return "Invalid credentials";

    }
}