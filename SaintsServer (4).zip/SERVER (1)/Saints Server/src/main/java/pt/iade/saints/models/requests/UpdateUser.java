package pt.iade.saints.models.requests;

import java.util.Optional;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class UpdateUser {
    Optional<String> usrName;
    Optional<String> usrSenha;
}