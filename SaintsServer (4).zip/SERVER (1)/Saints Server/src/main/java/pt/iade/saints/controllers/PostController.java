package pt.iade.saints.controllers;

import org.springframework.http.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pt.iade.saints.models.Comentario;
import pt.iade.saints.models.Post;
import pt.iade.saints.models.repositories.ComentarioRepository;
import pt.iade.saints.models.repositories.PostRepository;
import pt.iade.saints.models.requests.Message;
import pt.iade.saints.models.requests.PostRequest;

import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(path = "/api/posts")
public class PostController {
    private Logger logger = LoggerFactory.getLogger(PostController.class);
    @Autowired
    private PostRepository postRepository;
    private ComentarioRepository comentarioRepository;

    @GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Post> getPosts() {
        List<Post> postsAll = postRepository.findAll();
        logger.info("Retrieving all posts");
        List<Post> postsFiltered = new ArrayList<>();
        for (Post post : postsAll) {
            OffsetDateTime createdAt = post.getCreatedAt();
            long timDiff = ChronoUnit.SECONDS.between(createdAt, OffsetDateTime.now());
            if (timDiff < 12 * 60 * 60)
                postsFiltered.add(post);
        }
        logger.info("Returning all filtered posts");
        return postsFiltered;
    }

    @PostMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Post addPost(@RequestBody PostRequest postRequest) {
        Post post = new Post();
        post.setPostUsrId(postRequest.getPostUsrId());
        post.setPostBdId(postRequest.getPostBdId());
        post.setPostTxt(postRequest.getPostTxt());
        post.setPostVisivel(true);
        post.setCreatedAt(OffsetDateTime.now());
        logger.info("Saving post: {}", post.getPostTxt());
        return postRepository.save(post);
    }

    @DeleteMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message deleteTipo(@PathVariable Integer id) {
        logger.info("Deleting post by id: {}", id);
        postRepository.deleteById(id);
        return new Message("Sucesso");
    }

    @PatchMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public String updatePost(@RequestBody Post post) {
        logger.info("Update post: {}", post.getPostTxt());
        postRepository.save(post);
        return "Alterações efetuadas com sucesso!";
    }

    @GetMapping(path = "/{id}/comentarios", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Comentario> getComentariosByPost(@PathVariable Integer id) {
        return comentarioRepository.findComentariosByPost(id);
    }
}
