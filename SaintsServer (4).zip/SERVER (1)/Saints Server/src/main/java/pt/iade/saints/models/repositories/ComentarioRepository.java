package pt.iade.saints.models.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import pt.iade.saints.models.Comentario;

import java.util.List;

@Repository
public interface ComentarioRepository extends CrudRepository<Comentario, Integer> {
    @Override
    List<Comentario> findAll();

    @Query(value = "Select * from comentario where com_post_id = ?1", nativeQuery = true)
    List<Comentario> findComentariosByPost(Integer postId);
}