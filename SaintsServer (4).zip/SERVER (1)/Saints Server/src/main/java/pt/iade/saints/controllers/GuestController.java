package pt.iade.saints.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import pt.iade.saints.models.Tipo;
import pt.iade.saints.models.repositories.TipoRepository;
import pt.iade.saints.models.requests.Message;

@RequestMapping(path = "/api/guests")
public class GuestController {
    private Logger logger = LoggerFactory.getLogger(GuestController.class);
    @Autowired
    private TipoRepository tipoRepository;

    @GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<Tipo> getTipos() {
        logger.info("Retrieving all tipos");
        return tipoRepository.findAll();
    }

    @GetMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Tipo getTipoById(@PathVariable Integer id) {
        logger.info("Retrieving tipo by id: {}", id);
        return tipoRepository.findTipoById(id);
    }

    @PostMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Tipo addTipo(@RequestBody Tipo tipo) {
        logger.info("Saving tipo: {}", tipo.getTpNome());
        return tipoRepository.save(tipo);
    }

    @DeleteMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message deleteTipo(@PathVariable Integer id) {
        logger.info("Deleting tipo by id: {}", id);
        tipoRepository.deleteById(id);
        return new Message("Sucesso");
    }

    @PatchMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public String updateTipo(@RequestBody Tipo tipo) {
        logger.info("Update tipo: {}", tipo.getTpNome());
        tipoRepository.save(tipo);
        return "Alterações efetuadas com sucesso!";
    }
}