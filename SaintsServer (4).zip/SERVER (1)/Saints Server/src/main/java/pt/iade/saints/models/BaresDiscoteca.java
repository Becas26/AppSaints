package pt.iade.saints.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "baresdiscotecas")
public class BaresDiscoteca {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bd_id", nullable = false)
    private Integer id;

    @Column(name = "bd_name", nullable = false, length = 200)
    private String bdName;

    @Column(name = "bd_loc", nullable = false, length = 200)
    private String bdLoc;

    @Column(name = "bd_horario", nullable = false, length = 200)
    private String bdHorario;

    @Column(name = "bd_tipo_id")
    private Integer bdTipoId;

    @Column(name = "bd_latitude")
    private double bdLatitude;

    @Column(name = "bd_longitude")
    private double bdLongitude;

    @Column(name = "bd_contact", length = 100)
    private String bdContact;
}