package pt.iade.saints.controllers;

import java.util.Optional;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pt.iade.saints.models.User;
import pt.iade.saints.models.repositories.UserRepository;
import pt.iade.saints.models.requests.Message;
import pt.iade.saints.models.requests.PostUser;
import pt.iade.saints.models.requests.UpdateUser;

@RestController
@RequestMapping(path = "/api/users")
public class UserController {
    private static final String RP_CODE = "codigorp2022";
    private static final String CEO_CODE = "codigoceo2022";
    private Logger logger = LoggerFactory.getLogger(UserController.class);
    @Autowired
    private UserRepository userRepository;

    @GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<User> getUsers() {
        logger.info("Retrieving users");
        return userRepository.findAll();
    }

    @GetMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public User getUserById(@PathVariable Integer id) {
        logger.info("Getting user by id: {}", id);
        return userRepository.findById(id).orElseThrow();
    }

    @GetMapping(path = "/name/{name}", produces = MediaType.APPLICATION_JSON_VALUE)
    public User getUserByName(@PathVariable String name) {
        logger.info("Getting user by id: {}", name);
        return userRepository.findUserByUsrName(name);
    }

    @PostMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public User addUser(@RequestBody PostUser user) {
        User newUser = new User();
        newUser.setUsrName(user.getUsrName());
        newUser.setUsrSenha(user.getUsrSenha());
        newUser.setUsrTele(user.getUsrTele());
        newUser.setUsrActive(true);
        newUser.setUsrBdate(user.getUsrBdate());
        logger.info("Saving user: {}", user.getUsrName());
        String wordlist = "0123456789";
        StringBuilder stringBuilder = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 7; i++)
            stringBuilder.append(wordlist.charAt(random.nextInt(wordlist.length())));
        String codigo = stringBuilder.toString();
        newUser.setUsrCode(codigo);
        Optional<String> rpCeoCode = user.getRpCeoCode();
        if (rpCeoCode.isPresent()) {
            if (rpCeoCode.get().equalsIgnoreCase(RP_CODE))
                newUser.setUsrIsRp(true);
            else if (rpCeoCode.get().equalsIgnoreCase(CEO_CODE))
                newUser.setUsrIsCeo(true);
        }

        logger.info("codigo de verificacao!: {}", codigo);
        return userRepository.save(newUser);
    }

    @DeleteMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message deleteUser(@PathVariable Integer id) {

        logger.info("Deleting user by id: {}", id);
        userRepository.deleteById(id);
        return new Message("Sucesso");
    }

    @PatchMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message updateUser(@PathVariable Integer id, @RequestBody UpdateUser user) {
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isPresent()) {
            User oldUser = optionalUser.get();
            oldUser.setUsrName(user.getUsrName().orElse(oldUser.getUsrName()));
            oldUser.setUsrSenha(user.getUsrSenha().orElse(oldUser.getUsrSenha()));

            logger.info("Updating user: {}", oldUser.getUsrName());
            userRepository.save(oldUser);
            return new Message("Alterações efetuadas com sucesso");
        }
        return new Message("Alterações efetuadas sem sucesso");
    }
}