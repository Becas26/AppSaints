package pt.iade.saints.models.requests;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Optional;

@Getter
@Setter
@AllArgsConstructor
public class PostUser {
    private String usrName;
    private String usrSenha;
    private LocalDate usrBdate;
    private String usrTele;
    private Boolean usrActive = false;
    private Optional<String> rpCeoCode;
}