package pt.iade.saints.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "ceo")
public class Ceo {
    @Id
    @Column(name = "ceo_id", nullable = false)
    private Integer id;

    @Column(name = "ceo_usr_id")
    private Integer ceoUsrId;

    @Column(name = "ceo_cod", nullable = false, length = 100)
    private String ceoCod;
}
