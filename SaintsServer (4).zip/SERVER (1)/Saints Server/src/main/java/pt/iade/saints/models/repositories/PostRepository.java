package pt.iade.saints.models.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import pt.iade.saints.models.Post;

import java.util.List;

@Repository
public interface PostRepository extends CrudRepository<Post, Integer> {
    @Override
    List<Post> findAll();

    @Query(value = "Select * from post where post_bd_id = ?1", nativeQuery = true)
    List<Post> findPostByEstabelecimentoId(Integer postId);

}