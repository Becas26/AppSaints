package pt.iade.saints.controllers;

import org.springframework.http.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import pt.iade.saints.models.BaresDiscoteca;
import pt.iade.saints.models.Imagens;
import pt.iade.saints.models.Post;
import pt.iade.saints.models.Tipo;
import pt.iade.saints.models.repositories.BaresDiscotecasRepository;
import pt.iade.saints.models.repositories.ImagensRepository;
import pt.iade.saints.models.repositories.PostRepository;
import pt.iade.saints.models.repositories.TipoRepository;
import pt.iade.saints.models.requests.Message;
import pt.iade.saints.models.requests.UpdateBarDisc;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "/api/estabelecimentos")
public class BaresDiscotecasController {
    private final Logger logger = LoggerFactory.getLogger(BaresDiscotecasController.class);
    @Autowired
    private BaresDiscotecasRepository baresdiscotecasRepository;
    @Autowired
    private ImagensRepository imagensRepository;
    private PostRepository postRepository;
    @Autowired
    TipoRepository tipoRepository;

    @GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<BaresDiscoteca> getBaresDiscotecas() {
        logger.info("Retrieving all baresdiscotecas");
        return baresdiscotecasRepository.findAll();
    }

    @GetMapping(path = "/locate/{latitude}/{longitude}")
    public BaresDiscoteca locateBarDiscoteca(@PathVariable double latitude, @PathVariable double longitude) throws Exception {
        Iterable<BaresDiscoteca> baresDiscotecas = baresdiscotecasRepository.findAll();
        for (BaresDiscoteca bd : baresDiscotecas) {
            double bdLatitude = bd.getBdLatitude();
            double bdLongitude = bd.getBdLongitude();
            double threshold = 0.0003;

            if(Math.abs(bdLatitude - latitude) < threshold && Math.abs(bdLongitude - longitude) < threshold) {
                return bd;
            }
        }
        throw new Exception();
    }

    @PostMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public BaresDiscoteca addBaresDiscotecas(@RequestBody BaresDiscoteca baresDiscoteca) {
        logger.info("Saving baresdiscotecas: {}", baresDiscoteca.getBdName());
        return baresdiscotecasRepository.save(baresDiscoteca);
    }

    @DeleteMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message deleteTipo(@PathVariable Integer id) {
        logger.info("Deleting baresdiscotecas by id: {}", id);
        baresdiscotecasRepository.deleteById(id);
        return new Message("Sucesso");
    }

    @PatchMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message updateBaresDiscotecas(@PathVariable Integer id, @RequestBody UpdateBarDisc baresDiscoteca) {
        Optional<BaresDiscoteca> optionalBarDisc = baresdiscotecasRepository.findById(id);
        if (optionalBarDisc.isPresent()) {
            BaresDiscoteca oldBarDisc = optionalBarDisc.get();
            logger.info("Updating bar/disco: {}", oldBarDisc.getBdName());
            oldBarDisc.setBdName(baresDiscoteca.getBdName().orElse(oldBarDisc.getBdName()));
            oldBarDisc.setBdLoc(baresDiscoteca.getBdLoc().orElse(oldBarDisc.getBdLoc()));
            oldBarDisc.setBdHorario(baresDiscoteca.getBdHorario().orElse(oldBarDisc.getBdHorario()));
            oldBarDisc.setBdContact(baresDiscoteca.getBdContact().orElse(oldBarDisc.getBdContact()));
            baresdiscotecasRepository.save(oldBarDisc);
            return new Message("Alterações efetuadas com sucesso");
        }
        return new Message("Alterações efetuadas sem sucesso");
    }

    @GetMapping(path = "/{name}", produces = MediaType.APPLICATION_JSON_VALUE)
    public BaresDiscoteca getBareDiscotecaByName(@PathVariable String name) {
        name = URLDecoder.decode(name, StandardCharsets.UTF_8);
        logger.info("Retrieving object from name: {}", name);
        logger.info("Retrieved: {}", baresdiscotecasRepository.findBaresDiscotecaByBdName(name).getBdName());
        return baresdiscotecasRepository.findBaresDiscotecaByBdName(name);
    }

    @GetMapping(path = "/id/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public BaresDiscoteca getBareDiscotecaById(@PathVariable Integer id) {
        return baresdiscotecasRepository.findById(id).orElseThrow();
    }

    @GetMapping(path = "/{name}/imagens", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Imagens> getImagensByBaresDiscoteca(@PathVariable String name) {
        logger.info(name);
        name = URLDecoder.decode(name, StandardCharsets.UTF_8);
        Integer bdId = baresdiscotecasRepository.findBaresDiscotecaByBdName(name).getId();
        logger.info(bdId.toString());
        return imagensRepository.findImagensByEstabelecimentoId(bdId);
    }

    @GetMapping(path = "/{id}/posts", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Post> getPostsByBaresDiscoteca(@PathVariable Integer id) {
        return postRepository.findPostByEstabelecimentoId(id);
    }

    @GetMapping(path = "/tipo/{tpName}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<BaresDiscoteca> getBareDiscotecaByTipo(@PathVariable String tpName) {
        Tipo tipo = tipoRepository.findTipoByTpNome(tpName);
        return baresdiscotecasRepository.findBaresDiscotecasByBdTipoId(tipo.getId());
    }
}