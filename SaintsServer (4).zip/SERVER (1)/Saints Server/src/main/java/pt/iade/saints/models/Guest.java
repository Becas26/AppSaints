package pt.iade.saints.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Getter
@Setter
@Table(name = "guest")
public class Guest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "guest_id ")
    private int id;
    @Column(name = "guest_rp_id")
    private int rp_id;
    @Column(name = "guest_bd_id")
    private int bd_id;
    @Column(name = "guest_txt")
    private String txt;
}