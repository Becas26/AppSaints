package pt.iade.saints.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RP")
public class Rp {
    @Id
    @Column(name = "rp_id", nullable = false)
    private Integer id;

    @Column(name = "rp_usr_id")
    private Integer rpUsrId;

    @Column(name = "rp_cod", nullable = false, length = 40)
    private String rpCod;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRpUsrId() {
        return rpUsrId;
    }

    public void setRpUsrId(Integer rpUsrId) {
        this.rpUsrId = rpUsrId;
    }

    public String getRpCod() {
        return rpCod;
    }

    public void setRpCod(String rpCod) {
        this.rpCod = rpCod;
    }

}