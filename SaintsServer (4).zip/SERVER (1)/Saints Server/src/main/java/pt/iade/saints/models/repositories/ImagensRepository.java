package pt.iade.saints.models.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import pt.iade.saints.models.Imagens;

@Repository
public interface ImagensRepository extends CrudRepository<Imagens, Integer> {
    List<Imagens> findAll();

    @Query(value = "Select * from imagens where img_bd_id = ?1", nativeQuery = true)
    List<Imagens> findImagensByEstabelecimentoId(Integer baresDiscotecaId);
}