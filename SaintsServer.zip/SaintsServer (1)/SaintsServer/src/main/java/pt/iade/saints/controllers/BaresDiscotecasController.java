package pt.iade.saints.controllers;

import org.springframework.http.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import pt.iade.saints.models.BaresDiscoteca;
import pt.iade.saints.models.Tipo;
import pt.iade.saints.models.repositories.BaresDiscotecasRepository;
import pt.iade.saints.models.repositories.TipoRepository;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;


@RestController
@RequestMapping(path = "/api/baresdiscoteca")
public class BaresDiscotecasController {
    private final Logger logger = LoggerFactory.getLogger(BaresDiscotecasController.class);
    @Autowired
    private BaresDiscotecasRepository baresdiscotecasRepository;

    @Autowired
    TipoRepository tipoRepository;

    @GetMapping(path = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<BaresDiscoteca> getBaresDiscotecas() {
        logger.info("Retrieving all baresdiscotecas");
        return baresdiscotecasRepository.findAll();
    }

    @PostMapping(path = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public BaresDiscoteca addBaresDiscotecas(@RequestBody BaresDiscoteca baresDiscoteca) {

        logger.info("Saving baresdiscotecas: {}", baresDiscoteca.getBdName());
        return baresdiscotecasRepository.save(baresDiscoteca);
    }
    @DeleteMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public String deleteBaresDiscotecas(@RequestBody BaresDiscoteca baresDiscoteca) {
        logger.info("Deleting baresdiscotecas: {}", baresDiscoteca.getBdName());
        baresdiscotecasRepository.delete(baresDiscoteca);
        return "Sucesso";
    }

    @PatchMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public String updateBaresDiscotecas(@RequestBody BaresDiscoteca baresDiscoteca) {
        logger.info("Update baresdiscotecas: {}", baresDiscoteca.getBdName());
        baresdiscotecasRepository.save(baresDiscoteca);
        return "Alterações efetuadas com sucesso!";
    }

    @GetMapping(path = "/{name}", produces = MediaType.APPLICATION_JSON_VALUE)
    public BaresDiscoteca getBareDiscotecaByName(@PathVariable String name) {
        name = URLDecoder.decode(name, StandardCharsets.UTF_8);
        logger.info("Retrieving object from name: {}", name);
        logger.info("Retrieved: {}", baresdiscotecasRepository.findBaresDiscotecaByBdName(name).getBdName());
        return baresdiscotecasRepository.findBaresDiscotecaByBdName(name);
    }

    @GetMapping(path = "/tipo/{tpName}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<BaresDiscoteca> getBareDiscotecaByTipo(@PathVariable String tpName) {
        Tipo tipo = tipoRepository.findTipoByTpNome(tpName);
        return baresdiscotecasRepository.findBaresDiscotecasByBdTipoId(tipo.getId());
    }
}
