package pt.iade.saints.controllers;

import org.springframework.http.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pt.iade.saints.models.Post;
import pt.iade.saints.models.repositories.PostRepository;

@RestController
@RequestMapping(path = "/api/post")
public class PostController {
    private Logger logger = LoggerFactory.getLogger(PostController.class);
    @Autowired
    private PostRepository postRepository;

    @GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<Post> getPosts() {
        logger.info("Retrieving all posts");
        return postRepository.findAll();
    }

    @PostMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Post addPost(@RequestBody Post post) {

        logger.info("Saving post: {}", post.getPostTxt());
        return postRepository.save(post);
    }

    @DeleteMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public String deletePost(@RequestBody Post post) {
        logger.info("Deleting post: {}", post.getPostTxt());
        postRepository.delete(post);
        return "Sucesso!";
    }

    public void updatePost(@RequestBody Post post) {
        logger.info("Update post: {}", post.getPostTxt());
        postRepository.save(post);
    }
    @PatchMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public String updateUser(@RequestBody Post post) {
        logger.info("Update post: {}", post.getPostTxt());
        postRepository.save(post);
        return "Alterações efetuadas com sucesso!";
    }
} 
