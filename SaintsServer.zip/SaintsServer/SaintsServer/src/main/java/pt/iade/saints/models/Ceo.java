package pt.iade.saints.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ceo")
public class Ceo {
    @Id
    @Column(name = "ceo_id", nullable = false)
    private Integer id;

    @Column(name = "ceo_usr_id")
    private Integer ceoUsrId;

    @Column(name = "ceo_cod", nullable = false, length = 100)
    private String ceoCod;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCeoUsrId() {
        return ceoUsrId;
    }

    public void setCeoUsrId(Integer ceoUsrId) {
        this.ceoUsrId = ceoUsrId;
    }

    public String getCeoCod() {
        return ceoCod;
    }

    public void setCeoCod(String ceoCod) {
        this.ceoCod = ceoCod;
    }

}

