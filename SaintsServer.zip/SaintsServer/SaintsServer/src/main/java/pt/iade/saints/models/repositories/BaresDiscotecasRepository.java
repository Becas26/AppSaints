package pt.iade.saints.models.repositories;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import pt.iade.saints.models.BaresDiscoteca;


@Repository
public interface BaresDiscotecasRepository extends CrudRepository<BaresDiscoteca, Long> {
    List<BaresDiscoteca> findAll();
    BaresDiscoteca findBaresDiscotecaByBdName(String name);

    BaresDiscoteca findBaresDiscotecaByBdTipoId(Integer tipoId);

    List<BaresDiscoteca> findBaresDiscotecasByBdTipoId(Integer tipoId);
}