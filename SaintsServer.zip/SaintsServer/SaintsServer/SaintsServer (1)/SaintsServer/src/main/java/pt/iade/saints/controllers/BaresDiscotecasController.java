package pt.iade.saints.controllers;

import org.springframework.http.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import pt.iade.saints.models.BaresDiscoteca;
import pt.iade.saints.models.Tipo;
import pt.iade.saints.models.repositories.BaresDiscotecasRepository;
import pt.iade.saints.models.repositories.TipoRepository;
import pt.iade.saints.models.requests.Message;
import pt.iade.saints.models.requests.UpdateBarDisc;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Optional;


@RestController
@RequestMapping(path = "/api/baresdiscoteca")
public class BaresDiscotecasController {
    private final Logger logger = LoggerFactory.getLogger(BaresDiscotecasController.class);
    @Autowired
    private BaresDiscotecasRepository baresdiscotecasRepository;

    @Autowired
    TipoRepository tipoRepository;

    @GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<BaresDiscoteca> getBaresDiscotecas() {
        logger.info("Retrieving all baresdiscotecas");
        return baresdiscotecasRepository.findAll();
    }

    @PostMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public BaresDiscoteca addBaresDiscotecas(@RequestBody BaresDiscoteca baresDiscoteca) {

        logger.info("Saving baresdiscotecas: {}", baresDiscoteca.getBdName());
        return baresdiscotecasRepository.save(baresDiscoteca);
    }

    @DeleteMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message deleteTipo(@PathVariable Integer id) {
        logger.info("Deleting baresdiscotecas by id: {}", id);
        baresdiscotecasRepository.deleteById(id);
        return new Message("Sucesso");
    }

    @PatchMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message updateBaresDiscotecas(@PathVariable Integer id, @RequestBody UpdateBarDisc baresDiscoteca) {
        
        Optional<BaresDiscoteca> optionalBarDisc = baresdiscotecasRepository.findById(id);
        if(optionalBarDisc.isPresent()) {
            BaresDiscoteca oldBarDisc = optionalBarDisc.get();

            logger.info("Updating bar/disco: {}", oldBarDisc.getBdName());
            oldBarDisc.setBdName(baresDiscoteca.getBdName().orElse(oldBarDisc.getBdName()));
            oldBarDisc.setBdLoc(baresDiscoteca.getBdLoc().orElse(oldBarDisc.getBdLoc()));
            oldBarDisc.setBdHorario(baresDiscoteca.getBdHorario().orElse(oldBarDisc.getBdHorario()));
            oldBarDisc.setBdContact(baresDiscoteca.getBdContact().orElse(oldBarDisc.getBdContact()));
            baresdiscotecasRepository.save(oldBarDisc);
            return new Message("Alterações efetuadas com sucesso");
        }
        return new Message("Alterações efetuadas sem sucesso");
    }

    @GetMapping(path = "/{name}", produces = MediaType.APPLICATION_JSON_VALUE)
    public BaresDiscoteca getBareDiscotecaByName(@PathVariable String name) {
        name = URLDecoder.decode(name, StandardCharsets.UTF_8);
        logger.info("Retrieving object from name: {}", name);
        logger.info("Retrieved: {}", baresdiscotecasRepository.findBaresDiscotecaByBdName(name).getBdName());
        return baresdiscotecasRepository.findBaresDiscotecaByBdName(name);
    }

    @GetMapping(path = "/tipo/{tpName}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<BaresDiscoteca> getBareDiscotecaByTipo(@PathVariable String tpName) {
        Tipo tipo = tipoRepository.findTipoByTpNome(tpName);
        return baresdiscotecasRepository.findBaresDiscotecasByBdTipoId(tipo.getId());
    }
}
