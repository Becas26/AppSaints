package pt.iade.saints.models;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "usr_id", nullable = false)
    private Integer id;

    @Column(name = "usr_name", nullable = false, length = 100)
    private String usrName;

    @Column(name = "usr_senha", nullable = false, length = 20)
    private String usrSenha;

    @Column(name = "usr_bdate", nullable = false)
    private LocalDate usrBdate;

    @Column(name = "usr_tele", nullable = false, length = 100)
    private String usrTele;

    @Column(name = "usr_active", nullable = false)
    private Boolean usrActive = false;

    @Column(name = "usr_code", nullable = false)
    private String usrCode;

    @Column(name = "usr_rp_ceo_code", nullable = true)
    private String usrRpCeoCode;

    @OneToMany(fetch=FetchType.LAZY,mappedBy="postUsrId")
    private Set<Post> posts = new LinkedHashSet<>();

    @OneToMany(fetch=FetchType.LAZY, mappedBy = "usr_id")
    private Set<Comentario> comentarios = new LinkedHashSet<>();

    @OneToMany(fetch=FetchType.LAZY, mappedBy = "compUsrId")
    private Set<Cpermanente> cpermanentes = new LinkedHashSet<>();
}