package pt.iade.saints.controllers;

import org.springframework.http.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pt.iade.saints.models.Imagens;
import pt.iade.saints.models.repositories.ImagensRepository;
import pt.iade.saints.models.requests.Message;



@RestController
@RequestMapping(path = "/api/imagens")
public class ImagensController {
    private Logger logger = LoggerFactory.getLogger(ImagensController.class);
    @Autowired
    private ImagensRepository imagensRepository;

    @GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<Imagens> getImagens() {
        logger.info("Retrieving all imagens");
        return imagensRepository.findAll();
    }

    @PostMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Imagens addImagens(@RequestBody Imagens imagens) {

        logger.info("Saving imagens: {}", imagens.getImgUrl());
        return imagensRepository.save(imagens);
    }

    @DeleteMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message deleteTipo(@PathVariable Integer id) {
        logger.info("Deleting imagens by id: {}", id);
        imagensRepository.deleteById(id);
        return new Message("Sucesso");
    }

    @PatchMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public String updateimagens(@RequestBody Imagens imagens) {
        logger.info("Update imagens: {}", imagens.getImgUrl());
        imagensRepository.save(imagens);
        return "Alterações efetuadas com sucesso!";
    }
} 
