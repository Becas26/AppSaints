package pt.iade.saints.models.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import pt.iade.saints.models.Imagens;


@Repository
public interface ImagensRepository extends CrudRepository<Imagens, Integer> {
    @Override
    Iterable<Imagens> findAll();
}