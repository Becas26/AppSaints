package pt.iade.saints.controllers;

import org.springframework.http.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pt.iade.saints.models.Post;
import pt.iade.saints.models.repositories.PostRepository;
import pt.iade.saints.models.requests.Message;

@RestController
@RequestMapping(path = "/api/post")
public class PostController {
    private Logger logger = LoggerFactory.getLogger(PostController.class);
    @Autowired
    private PostRepository postRepository;

    @GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<Post> getPosts() {
        logger.info("Retrieving all posts");
        return postRepository.findAll();
    }

    @PostMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Post addPost(@RequestBody Post post) {

        logger.info("Saving post: {}", post.getPostTxt());
        return postRepository.save(post);
    }

    @DeleteMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message deleteTipo(@PathVariable Integer id) {
        logger.info("Deleting post by id: {}", id);
      postRepository.deleteById(id);
        return new Message("Sucesso");
    }

    public void updatePost(@RequestBody Post post) {
        logger.info("Update post: {}", post.getPostTxt());
        postRepository.save(post);
    }
    @PatchMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public String updateUser(@RequestBody Post post) {
        logger.info("Update post: {}", post.getPostTxt());
        postRepository.save(post);
        return "Alterações efetuadas com sucesso!";
    }
} 
