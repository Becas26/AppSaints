package pt.iade.saints.models.repositories;

import org.springframework.data.repository.CrudRepository;
import pt.iade.saints.models.Tipo;

public interface TipoRepository extends CrudRepository<Tipo, Integer> {
    Tipo findTipoById(Integer id);
    Tipo findTipoByTpNome(String name);
}
