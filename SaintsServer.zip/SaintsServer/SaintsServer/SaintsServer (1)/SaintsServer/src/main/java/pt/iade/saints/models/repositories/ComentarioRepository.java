package pt.iade.saints.models.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import pt.iade.saints.models.Comentario;

@Repository
public interface ComentarioRepository extends CrudRepository<Comentario, Integer> {
}