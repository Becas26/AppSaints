package pt.iade.saints.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cpermanente")
public class Cpermanente {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "comp_id", nullable = false)
    private Integer id;

    @Column(name = "comp_bd_id")
    private Integer compBdId;

    @Column(name="comp_usr_id")
    private Integer compUsrId;

    @Column(name = "comp_txt", nullable = false, length = 100)
    private String compTxt;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCompBdId() {
        return compBdId;
    }

    public void setCompBdId(Integer compBdId) {
        this.compBdId = compBdId;
    }

    public Integer getCompUsr() {
        return compUsrId;
    }

    public String getCompTxt() {
        return compTxt;
    }

    public void setCompTxt(String compTxt) {
        this.compTxt = compTxt;
    }
}
