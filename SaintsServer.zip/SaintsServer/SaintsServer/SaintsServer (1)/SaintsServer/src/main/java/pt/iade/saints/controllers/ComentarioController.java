package pt.iade.saints.controllers;

import org.springframework.http.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pt.iade.saints.models.Comentario;
import pt.iade.saints.models.repositories.ComentarioRepository;
import pt.iade.saints.models.requests.Message;


@RestController
@RequestMapping(path = "/api/comentario")
public class ComentarioController {
    private Logger logger = LoggerFactory.getLogger(ComentarioController.class);
    @Autowired
    private ComentarioRepository comentarioRepository;

    @GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<Comentario> getComentarios() {
        logger.info("Retrieving all comments");
        return comentarioRepository.findAll();
    }

    @PostMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Comentario addComentario(@RequestBody Comentario comentario) {

        logger.info("Saving comment: {}", comentario.getTxt());
        return comentarioRepository.save(comentario);
    }

    @DeleteMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Message deleteTipo(@PathVariable Integer id) {
        logger.info("Deleting comentario by id: {}", id);
        comentarioRepository.deleteById(id);
        return new Message("Sucesso");
    }

    @PatchMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public String updateComentario(@RequestBody Comentario comentario) {
        logger.info("Update comment: {}", comentario.getTxt());
        comentarioRepository.save(comentario);
        return "Alterações efetuadas com sucesso!";
    }
} 
