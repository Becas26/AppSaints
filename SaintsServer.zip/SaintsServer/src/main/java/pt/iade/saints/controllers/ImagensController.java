package pt.iade.saints.controllers;

import org.springframework.http.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pt.iade.saints.models.Imagens;
import pt.iade.saints.models.repositories.ImagensRepository;



@RestController
@RequestMapping(path = "/api/imagens")
public class ImagensController {
    private Logger logger = LoggerFactory.getLogger(ImagensController.class);
    @Autowired
    private ImagensRepository imagensRepository;

    @GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<Imagens> getComentarios() {
        logger.info("Retrieving all comments");
        return imagensRepository.findAll();
    }

    @PostMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public Imagens addImagens(@RequestBody Imagens imagens) {

        logger.info("Saving imagens: {}", imagens.getImgUrl());
        return imagensRepository.save(imagens);
    }

    @DeleteMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public void deleteimagens(@RequestBody Imagens imagens) {
        logger.info("Deleting imagens: {}", imagens.getImgUrl());
        imagensRepository.delete(imagens);
    }

    @PatchMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE)
    public void updateimagens(@RequestBody Imagens imagens) {
        logger.info("Update imagens: {}", imagens.getImgUrl());
        imagensRepository.save(imagens);
    }
} 
