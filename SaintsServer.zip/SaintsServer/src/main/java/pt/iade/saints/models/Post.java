package pt.iade.saints.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "post")
public class Post {
    @Id
    @Column(name = "post_id", nullable = false)
    private Integer id;

    @Column(name = "post_usr_id")
    private Integer postUsrId;

    @Column(name = "post_bd_id", nullable = false)
    private Integer postBdId;

    @Column(name = "post_txt", nullable = false, length = 200)
    private String postTxt;

    @Column(name = "post_visivel", nullable = false)
    private Boolean postVisivel = false;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPostUsr() {
        return postUsrId;
    }

    public Integer getPostBd() {
        return postBdId;
    }

    public void setPostBd(Integer postBd) {
        this.postBdId = postBd;
    }

    public String getPostTxt() {
        return postTxt;
    }

    public void setPostTxt(String postTxt) {
        this.postTxt = postTxt;
    }

    public Boolean getPostVisivel() {
        return postVisivel;
    }

    public void setPostVisivel(Boolean postVisivel) {
        this.postVisivel = postVisivel;
    }

}
