package pt.iade.saints.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity  
@Table(name="comentario") 
public class Comentario { 
    @Id 
    @GeneratedValue(strategy=GenerationType.IDENTITY) 
    @Column(name="com_id")  
    private int id; 
    @Column(name="com_usr_id")
    private int usr_id; 
    @Column(name="com_post_id") 
    private int post_id; 
    @Column(name="com_txt") 
    private String txt; 
    @Column(name="com_visivel") 
    private Boolean visivel;
    public Comentario() {}
    public int getId() { return id; }
    public void setId(int id) {
        this.id = id;
    }
    public int getUsr_id() {
        return usr_id;
    }
    public void setUsr_id(int usr_id) {
        this.usr_id = usr_id;
    }
    public int getPost_id() {
        return post_id;
    }
    public void setPost_id(int post_id) {
        this.post_id = post_id;
    }
    public String getTxt() {
        return txt;
    }
    public void setTxt(String txt) {
        this.txt = txt;
    }
    public Boolean getVisivel() {
        return visivel;
    }
    public void setVisivel(Boolean visivel) {
        this.visivel = visivel;
    } 
}