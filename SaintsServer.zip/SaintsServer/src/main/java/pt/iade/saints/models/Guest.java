package pt.iade.saints.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="guest")
public class Guest {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="guest_id ") 
private int id;
@Column(name="guest_rp_id")
 private int rp_id;
@Column(name="guest_bd_id") 
private int bd_id;
@Column(name="guest_txt") 
private String txt;

public Guest() {}
public int getId() { return id; }
public void setId(int id) {
    this.id = id;
}
public int getRp_id() {
    return rp_id;
}
public void setRp_id(int rp_id) {
    this.rp_id = rp_id;
}
public int getBd_id() {
    return bd_id;
}
public void setBd_id(int bd_id) {
    this.bd_id = bd_id;
}
public String getTxt() {
    return txt;
}
public void setTxt(String txt) {
    this.txt = txt;
}

}
