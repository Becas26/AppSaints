package pt.iade.saints.models;

import javax.persistence.*;

@Entity
@Table(name = "baresdiscotecas")
public class BaresDiscoteca {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bd_id", nullable = false)
    private Integer id;

    @Column(name = "bd_name", nullable = false, length = 200)
    private String bdName;

    @Column(name = "bd_loc", nullable = false, length = 200)
    private String bdLoc;

    @Column(name = "bd_horario", nullable = false, length = 200)
    private String bdHorario;
    @Column(name="bd_tipo_id")
    private Integer bdTipoId;

    @Column(name = "bd_contact", length = 100)
    private String bdContact;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBdName() {
        return bdName;
    }

    public void setBdName(String bdName) {
        this.bdName = bdName;
    }

    public String getBdLoc() {
        return bdLoc;
    }

    public void setBdLoc(String bdLoc) {
        this.bdLoc = bdLoc;
    }

    public String getBdHorario() {
        return bdHorario;
    }

    public void setBdHorario(String bdHorario) {
        this.bdHorario = bdHorario;
    }

    public Integer getBdTipo() {
        return bdTipoId;
    }

    public void setBdTipo(Tipo bdTipo) {
        this.bdTipoId = bdTipoId;
    }

    public String getBdContact() {
        return bdContact;
    }

    public void setBdContact(String bdContact) {
        this.bdContact = bdContact;
    }

}