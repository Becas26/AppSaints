package pt.iade.saints.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "imagens")
public class Imagens {
    @Id
    @Column(name = "img_id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "img_bd_id", nullable = false)
    private BaresDiscoteca imgBd;

    @Column(name = "img_ceo_id", nullable = false)
    private Integer imgCeoId;

    @Column(name = "img_url", nullable = false, length = 200)
    private String imgUrl;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public BaresDiscoteca getImgBd() {
        return imgBd;
    }

    public void setImgBd(BaresDiscoteca imgBd) {
        this.imgBd = imgBd;
    }

    public Integer getImgCeoId() {
        return imgCeoId;
    }

    public void setImgCeoId(Integer imgCeoId) {
        this.imgCeoId = imgCeoId;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

}