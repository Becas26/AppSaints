package pt.iade.saints;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaintsApplicationTests {

	@Test
	void contextLoads() {
	}

}
