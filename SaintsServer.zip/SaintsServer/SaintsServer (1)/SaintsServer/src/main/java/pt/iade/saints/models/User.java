package pt.iade.saints.models;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "usr_id", nullable = false)
    private Integer id;

    @Column(name = "usr_name", nullable = false, length = 100)
    private String usrName;

    @Column(name = "usr_senha", nullable = false, length = 20)
    private String usrSenha;

    @Column(name = "usr_bdate", nullable = false)
    private LocalDate usrBdate;

    @Column(name = "usr_tele", nullable = false, length = 100)
    private String usrTele;

    @Column(name = "usr_active", nullable = false)
    private Boolean usrActive = false;

    @OneToMany(fetch=FetchType.LAZY,mappedBy="postUsrId")
    private Set<Post> posts = new LinkedHashSet<>();

    @OneToMany(fetch=FetchType.LAZY, mappedBy = "usr_id")
    private Set<Comentario> comentarios = new LinkedHashSet<>();

    @OneToMany(fetch=FetchType.LAZY, mappedBy = "compUsrId")
    private Set<Cpermanente> cpermanentes = new LinkedHashSet<>();

    public Set<Cpermanente> getCpermanentes() {
        return cpermanentes;
    }

    public void setCpermanentes(Set<Cpermanente> cpermanentes) {
        this.cpermanentes = cpermanentes;
    }

    public Set<Comentario> getComentarios() {
        return comentarios;
    }

    public void setComentarios(Set<Comentario> comentarios) {
        this.comentarios = comentarios;
    }

    public Set<Post> getPosts() {
        return posts;
    }

    public void setPosts(Set<Post> posts) {
        this.posts = posts;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsrName() {
        return usrName;
    }

    public void setUsrName(String usrName) {
        this.usrName = usrName;
    }

    public String getUsrSenha() {
        return usrSenha;
    }

    public void setUsrSenha(String usrSenha) {
        this.usrSenha = usrSenha;
    }

    public LocalDate getUsrBdate() {
        return usrBdate;
    }

    public void setUsrBdate(LocalDate usrBdate) {
        this.usrBdate = usrBdate;
    }

    public String getUsrTele() {
        return usrTele;
    }

    public void setUsrTele(String usrTele) {
        this.usrTele = usrTele;
    }

    public Boolean getUsrActive() {
        return usrActive;
    }

    public void setUsrActive(Boolean usrActive) {
        this.usrActive = usrActive;
    }

}