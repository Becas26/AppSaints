package com.example.listadiscotecas;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class BdRun extends AppCompatActivity {
    private Button buttonBar;
    private Button buttonDisco;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bd_run);
        buttonBar = (Button) findViewById(R.id.buttonBar);
        buttonBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityBar();
            }
        });
        buttonDisco=(Button) findViewById(R.id.buttonDisco);
        buttonDisco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityDisco();
            }
        });
    }

    private void openActivityBar(){
        Intent intent= new Intent(this, BarList.class);
        intent.putExtra("bdTipo", "Bar");
        startActivity(intent);
    }
    private void openActivityDisco(){
        Intent intent= new Intent(this, BarList.class);
        intent.putExtra("bdTipo", "Discoteca");
        startActivity(intent);
    }
}
